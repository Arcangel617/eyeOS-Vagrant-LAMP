-- phpMyAdmin SQL Dump
-- version 3.2.2.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 26-04-2010 a las 12:42:51
-- Versión del servidor: 5.1.37
-- Versión de PHP: 5.2.10-2ubuntu6.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de datos: `eyeos`
--

-- --------------------------------------------------------

--
-- Modificacion de tabla para la tabla `tagperimpressionto`
--
ALTER TABLE `tagperimpressionto` CHANGE `id` `id` INT( 11 ) NOT NULL AUTO_INCREMENT
