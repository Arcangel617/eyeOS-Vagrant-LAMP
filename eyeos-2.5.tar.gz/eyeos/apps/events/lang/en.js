lang['All Events'] = 'All Events';
lang['People'] = 'People';
lang['Groups'] = 'Groups';
lang['Applications'] = 'Applications';
lang['Events'] = 'Events';
