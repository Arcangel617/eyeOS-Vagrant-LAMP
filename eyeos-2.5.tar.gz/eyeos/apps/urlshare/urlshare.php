<?php
abstract class urlshareApplication extends EyeosApplicationExecutable {

    
}

?>
